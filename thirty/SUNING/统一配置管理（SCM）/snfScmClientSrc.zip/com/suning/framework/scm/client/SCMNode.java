package com.suning.framework.scm.client;

public abstract interface SCMNode
{
  public abstract String getValue()
    throws SCMException;
  
  public abstract void sync()
    throws SCMException;
  
  @Deprecated
  public abstract void monitor(SCMListener paramSCMListener);
  
  public abstract void monitor(String paramString, SCMListener paramSCMListener);
  
  public abstract void destroy();
}


/* Location:           F:\thirty\SUNING\统一配置管理（SCM）\snf-scm-client-2.2.0.jar
 * Qualified Name:     com.suning.framework.scm.client.SCMNode
 * JD-Core Version:    0.7.0.1
 */