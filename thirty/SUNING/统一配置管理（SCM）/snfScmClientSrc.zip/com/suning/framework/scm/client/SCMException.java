/*  1:   */ package com.suning.framework.scm.client;
/*  2:   */ 
/*  3:   */ public class SCMException
/*  4:   */   extends RuntimeException
/*  5:   */ {
/*  6:   */   private static final long serialVersionUID = -567786786121301727L;
/*  7:   */   
/*  8:   */   public SCMException(String message)
/*  9:   */   {
/* 10:13 */     super(message);
/* 11:   */   }
/* 12:   */   
/* 13:   */   public SCMException(String message, Throwable cause)
/* 14:   */   {
/* 15:17 */     super(message, cause);
/* 16:   */   }
/* 17:   */ }


/* Location:           F:\thirty\SUNING\统一配置管理（SCM）\snf-scm-client-2.2.0.jar
 * Qualified Name:     com.suning.framework.scm.client.SCMException
 * JD-Core Version:    0.7.0.1
 */