/*   1:    */ package com.suning.framework.scm.client;
/*   2:    */ 
/*   3:    */ import com.suning.framework.scm.util.HttpClient;
/*   4:    */ import com.suning.framework.scm.util.MD5Utils;
/*   5:    */ import com.suning.framework.scm.util.ParamUtil;
/*   6:    */ import com.suning.framework.scm.util.ServerNameGetter;
/*   7:    */ import com.suning.framework.scm.util.StringUtils;
/*   8:    */ import java.io.File;
/*   9:    */ import java.io.FileInputStream;
/*  10:    */ import java.io.FileWriter;
/*  11:    */ import java.io.IOException;
/*  12:    */ import java.io.InputStream;
/*  13:    */ import java.io.Writer;
/*  14:    */ import java.util.HashMap;
/*  15:    */ import java.util.Map;
/*  16:    */ import java.util.Properties;
/*  17:    */ import java.util.concurrent.ConcurrentHashMap;
/*  18:    */ import org.slf4j.Logger;
/*  19:    */ import org.slf4j.LoggerFactory;
/*  20:    */ 
/*  21:    */ public class SCMConfiguration
/*  22:    */ {
/*  23: 20 */   private static Logger logger = LoggerFactory.getLogger(SCMConfiguration.class);
/*  24: 21 */   protected static String CONFIG_FILE = "/scm.properties";
/*  25:    */   public static final String PATH_SEPARATOR = "/";
/*  26: 23 */   public static ConcurrentHashMap<String, SCMConfiguration> configs = new ConcurrentHashMap();
/*  27:    */   private SCMClient.Environment environment;
/*  28: 30 */   private String appCode = "";
/*  29: 34 */   private String secretKey = "";
/*  30: 38 */   private String scmServer = "";
/*  31: 39 */   private String zkServer = "";
/*  32:    */   
/*  33:    */   public static void setConfigFilePath(String path)
/*  34:    */   {
/*  35: 42 */     CONFIG_FILE = path;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public static SCMConfiguration getInstance()
/*  39:    */   {
/*  40: 46 */     return getInstance(CONFIG_FILE);
/*  41:    */   }
/*  42:    */   
/*  43:    */   public static SCMConfiguration getInstance(String configFile)
/*  44:    */   {
/*  45: 50 */     if (configs.containsKey(configFile)) {
/*  46: 51 */       return (SCMConfiguration)configs.get(configFile);
/*  47:    */     }
/*  48: 53 */     InputStream inputStream = SCMConfiguration.class.getResourceAsStream(configFile);
/*  49: 54 */     if (inputStream == null) {
/*  50: 55 */       throw new SCMException("Can not load file " + configFile);
/*  51:    */     }
/*  52:    */     try
/*  53:    */     {
/*  54: 58 */       Properties properties = new Properties();
/*  55: 59 */       properties.load(inputStream);
/*  56: 60 */       SCMConfiguration config = new SCMConfiguration(properties);
/*  57: 61 */       SCMConfiguration existed = (SCMConfiguration)configs.putIfAbsent(configFile, config);
/*  58: 62 */       if (existed != null) {
/*  59: 63 */         config = existed;
/*  60:    */       }
/*  61: 65 */       return config;
/*  62:    */     }
/*  63:    */     catch (Exception e)
/*  64:    */     {
/*  65: 67 */       throw new SCMException("load scm config error", e);
/*  66:    */     }
/*  67:    */     finally
/*  68:    */     {
/*  69:    */       try
/*  70:    */       {
/*  71: 70 */         inputStream.close();
/*  72:    */       }
/*  73:    */       catch (IOException e)
/*  74:    */       {
/*  75: 72 */         logger.error("close stream error", e);
/*  76:    */       }
/*  77:    */     }
/*  78:    */   }
/*  79:    */   
/*  80:    */   private String getDC()
/*  81:    */   {
/*  82: 78 */     String value = System.getenv("ldc");
/*  83: 79 */     if (StringUtils.isEmpty(value))
/*  84:    */     {
/*  85: 80 */       value = System.getProperty("ldc");
/*  86: 81 */       if (StringUtils.isEmpty(value)) {
/*  87: 82 */         throw new RuntimeException("Can not find ldc in environment.");
/*  88:    */       }
/*  89:    */     }
/*  90: 85 */     return value;
/*  91:    */   }
/*  92:    */   
/*  93:    */   private SCMConfiguration(Properties properties)
/*  94:    */   {
/*  95: 89 */     this.appCode = ((String)properties.get("appCode"));
/*  96: 90 */     this.secretKey = ((String)properties.get("secretKey"));
/*  97: 91 */     this.scmServer = ((String)properties.get("scmServer"));
/*  98: 92 */     Properties localCached = new Properties();
/*  99:    */     try
/* 100:    */     {
/* 101: 94 */       localCached = loadFromLocal();
/* 102:    */     }
/* 103:    */     catch (Exception e)
/* 104:    */     {
/* 105: 96 */       logger.warn("Can not load properties from local file.", e);
/* 106:    */     }
/* 107:    */     try
/* 108:    */     {
/* 109: 99 */       Map<String, Object> map = new HashMap();
/* 110:100 */       map.put("dc", getDC());
/* 111:101 */       this.zkServer = HttpClient.sendByPost(this.scmServer + "/zk.htm", ParamUtil.getEncodedParamFromMap(map), 30000, 3, 2000);
/* 112:    */       
/* 113:103 */       localCached.put("zkServer", this.zkServer);
/* 114:    */     }
/* 115:    */     catch (Exception ex)
/* 116:    */     {
/* 117:105 */       logger.error("Can not get zk list from scm server.", ex);
/* 118:106 */       this.zkServer = ((String)localCached.get("zkServer"));
/* 119:    */     }
/* 120:    */     try
/* 121:    */     {
/* 122:109 */       String isPrd = HttpClient.sendByPost(this.scmServer + "/isPrd.htm", "", 30000, 3, 2000);
/* 123:110 */       this.environment = (Boolean.valueOf(isPrd).booleanValue() ? SCMClient.Environment.PRD : SCMClient.Environment.NOT_PRD);
/* 124:111 */       localCached.put("scmEnv", this.environment.toString());
/* 125:    */     }
/* 126:    */     catch (Exception ex)
/* 127:    */     {
/* 128:113 */       logger.error("Can not get environment from scm server.", ex);
/* 129:114 */       Object env = localCached.get("scmEnv");
/* 130:115 */       if (null != env) {
/* 131:116 */         this.environment = SCMClient.Environment.valueOf(env.toString());
/* 132:    */       }
/* 133:    */     }
/* 134:119 */     if ((StringUtils.isEmpty(this.zkServer)) || (StringUtils.isEmpty(this.secretKey)) || (StringUtils.isEmpty(this.appCode)) || (StringUtils.isEmpty(this.scmServer)) || (null == this.environment)) {
/* 135:122 */       throw new SCMException("load scm config error,zkServer or appCode or scmServer or secretKey or scmEnv is null ");
/* 136:    */     }
/* 137:125 */     saveToLocal(localCached);
/* 138:    */   }
/* 139:    */   
/* 140:    */   private Properties loadFromLocal()
/* 141:    */     throws Exception
/* 142:    */   {
/* 143:129 */     String filePath = getLocalFilePath();
/* 144:130 */     File file = new File(filePath);
/* 145:131 */     if (!file.exists()) {
/* 146:132 */       return new Properties();
/* 147:    */     }
/* 148:134 */     FileInputStream in = new FileInputStream(file);
/* 149:135 */     properties = new Properties();
/* 150:    */     try
/* 151:    */     {
/* 152:137 */       properties.load(in);
/* 153:    */       
/* 154:    */ 
/* 155:    */ 
/* 156:    */ 
/* 157:    */ 
/* 158:    */ 
/* 159:    */ 
/* 160:145 */       return properties;
/* 161:    */     }
/* 162:    */     finally
/* 163:    */     {
/* 164:    */       try
/* 165:    */       {
/* 166:140 */         in.close();
/* 167:    */       }
/* 168:    */       catch (IOException e)
/* 169:    */       {
/* 170:142 */         logger.error("close stream error", e);
/* 171:    */       }
/* 172:    */     }
/* 173:    */   }
/* 174:    */   
/* 175:    */   private String getLocalFilePath()
/* 176:    */   {
/* 177:149 */     String md5 = MD5Utils.getMD5(this.scmServer + "_" + ServerNameGetter.getServerName());
/* 178:150 */     return System.getProperty("user.home") + "/" + SCMNodeImpl.StringFilter(md5);
/* 179:    */   }
/* 180:    */   
/* 181:    */   private void saveToLocal(Properties properties)
/* 182:    */   {
/* 183:154 */     String filePath = getLocalFilePath();
/* 184:155 */     File file = new File(filePath);
/* 185:156 */     Writer fw = null;
/* 186:    */     try
/* 187:    */     {
/* 188:158 */       if (!file.exists()) {
/* 189:159 */         file.createNewFile();
/* 190:    */       }
/* 191:161 */       fw = new FileWriter(file);
/* 192:162 */       properties.store(fw, "scm properties");
/* 193:166 */       if (null != fw) {
/* 194:    */         try
/* 195:    */         {
/* 196:168 */           fw.close();
/* 197:    */         }
/* 198:    */         catch (IOException e)
/* 199:    */         {
/* 200:170 */           logger.error("close stream error", e);
/* 201:    */         }
/* 202:    */       }
/* 203:    */       return;
/* 204:    */     }
/* 205:    */     catch (IOException ex)
/* 206:    */     {
/* 207:164 */       logger.error("Exception when save object to local.", ex);
/* 208:166 */       if (null != fw) {
/* 209:    */         try
/* 210:    */         {
/* 211:168 */           fw.close();
/* 212:    */         }
/* 213:    */         catch (IOException e)
/* 214:    */         {
/* 215:170 */           logger.error("close stream error", e);
/* 216:    */         }
/* 217:    */       }
/* 218:    */     }
/* 219:    */     finally
/* 220:    */     {
/* 221:166 */       if (null != fw) {
/* 222:    */         try
/* 223:    */         {
/* 224:168 */           fw.close();
/* 225:    */         }
/* 226:    */         catch (IOException e)
/* 227:    */         {
/* 228:170 */           logger.error("close stream error", e);
/* 229:    */         }
/* 230:    */       }
/* 231:    */     }
/* 232:    */   }
/* 233:    */   
/* 234:    */   public SCMClient.Environment getEnvironment()
/* 235:    */   {
/* 236:177 */     return this.environment;
/* 237:    */   }
/* 238:    */   
/* 239:    */   public String getAppCode()
/* 240:    */   {
/* 241:181 */     return this.appCode;
/* 242:    */   }
/* 243:    */   
/* 244:    */   public String getSecretKey()
/* 245:    */   {
/* 246:185 */     return this.secretKey;
/* 247:    */   }
/* 248:    */   
/* 249:    */   public String getScmServer()
/* 250:    */   {
/* 251:189 */     return this.scmServer;
/* 252:    */   }
/* 253:    */   
/* 254:    */   public String getZkServer()
/* 255:    */   {
/* 256:193 */     return this.zkServer;
/* 257:    */   }
/* 258:    */ }


/* Location:           F:\thirty\SUNING\统一配置管理（SCM）\snf-scm-client-2.2.0.jar
 * Qualified Name:     com.suning.framework.scm.client.SCMConfiguration
 * JD-Core Version:    0.7.0.1
 */