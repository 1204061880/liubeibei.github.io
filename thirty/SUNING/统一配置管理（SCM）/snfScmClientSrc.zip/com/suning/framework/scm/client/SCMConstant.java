/*  1:   */ package com.suning.framework.scm.client;
/*  2:   */ 
/*  3:   */ public class SCMConstant
/*  4:   */ {
/*  5:   */   public static final String C = "create";
/*  6:   */   public static final String U = "update";
/*  7:   */   public static final String D = "delete";
/*  8:   */   public static final String SCM_SERVER_DEV = "http://scmdev";
/*  9:   */   public static final String SCM_SERVER_SIT = "http://scmsit";
/* 10:   */   public static final String SCM_SERVER_PRE = "http://scmpre";
/* 11:   */   public static final String SCM_SERVER_XG_PRE = "http://scmxgpre";
/* 12:   */   public static final String SCM_SERVER_PST = "http://scmpst";
/* 13:   */   public static final String SCM_SERVER_POC = "http://scmpoc";
/* 14:   */   public static final String ENCODE = "UTF-8";
/* 15:55 */   public static final String FILE_PATH = System.getProperty("user.home");
/* 16:   */   public static final String REGEX = "[`~!@#$%^&*()+=|{}':;',//[//].<>/?~！@#￥%……&*（）——+|{}【】‘；：”“’。，、？]";
/* 17:   */ }


/* Location:           F:\thirty\SUNING\统一配置管理（SCM）\snf-scm-client-2.2.0.jar
 * Qualified Name:     com.suning.framework.scm.client.SCMConstant
 * JD-Core Version:    0.7.0.1
 */