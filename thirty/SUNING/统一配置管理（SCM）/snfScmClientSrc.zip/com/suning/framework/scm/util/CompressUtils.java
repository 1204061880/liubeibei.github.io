/*  1:   */ package com.suning.framework.scm.util;
/*  2:   */ 
/*  3:   */ import java.io.ByteArrayOutputStream;
/*  4:   */ import java.util.Arrays;
/*  5:   */ import java.util.zip.Deflater;
/*  6:   */ import java.util.zip.Inflater;
/*  7:   */ 
/*  8:   */ public final class CompressUtils
/*  9:   */ {
/* 10:15 */   private static final byte[] COMPRESS_PREFIX = { 0, 0, 0 };
/* 11:   */   
/* 12:   */   public static byte[] serialize(String str)
/* 13:   */   {
/* 14:21 */     if (StringUtils.isEmpty(str)) {
/* 15:22 */       return null;
/* 16:   */     }
/* 17:   */     try
/* 18:   */     {
/* 19:25 */       byte[] compressedData = compress(str.getBytes("UTF-8"));
/* 20:26 */       byte[] result = Arrays.copyOf(COMPRESS_PREFIX, COMPRESS_PREFIX.length + compressedData.length);
/* 21:27 */       System.arraycopy(compressedData, 0, result, COMPRESS_PREFIX.length, compressedData.length);
/* 22:28 */       return result;
/* 23:   */     }
/* 24:   */     catch (Exception e)
/* 25:   */     {
/* 26:30 */       throw new RuntimeException("serialize error", e);
/* 27:   */     }
/* 28:   */   }
/* 29:   */   
/* 30:   */   public static String deserialize(byte[] data)
/* 31:   */   {
/* 32:   */     try
/* 33:   */     {
/* 34:36 */       if ((data == null) || (data.length == 0)) {
/* 35:37 */         return null;
/* 36:   */       }
/* 37:40 */       if (data.length < COMPRESS_PREFIX.length) {
/* 38:41 */         return new String(data, "UTF-8");
/* 39:   */       }
/* 40:43 */       byte[] prefix = Arrays.copyOfRange(data, 0, COMPRESS_PREFIX.length);
/* 41:44 */       byte[] originData = data;
/* 42:46 */       if (Arrays.equals(COMPRESS_PREFIX, prefix))
/* 43:   */       {
/* 44:47 */         originData = Arrays.copyOfRange(data, COMPRESS_PREFIX.length, data.length);
/* 45:48 */         if (originData.length == 0) {
/* 46:49 */           return null;
/* 47:   */         }
/* 48:51 */         originData = uncompress(originData);
/* 49:   */       }
/* 50:53 */       return new String(originData, "UTF-8");
/* 51:   */     }
/* 52:   */     catch (Exception ex)
/* 53:   */     {
/* 54:55 */       throw new RuntimeException(ex);
/* 55:   */     }
/* 56:   */   }
/* 57:   */   
/* 58:   */   private static byte[] compress(byte[] inputByte)
/* 59:   */     throws Exception
/* 60:   */   {
/* 61:60 */     Deflater deflater = new Deflater();
/* 62:61 */     deflater.setInput(inputByte);
/* 63:62 */     deflater.finish();
/* 64:63 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/* 65:64 */     byte[] outputByte = new byte[1024];
/* 66:   */     try
/* 67:   */     {
/* 68:67 */       while (!deflater.finished())
/* 69:   */       {
/* 70:68 */         int len = deflater.deflate(outputByte);
/* 71:69 */         bos.write(outputByte, 0, len);
/* 72:   */       }
/* 73:   */     }
/* 74:   */     finally
/* 75:   */     {
/* 76:72 */       deflater.end();
/* 77:73 */       bos.close();
/* 78:   */     }
/* 79:75 */     return bos.toByteArray();
/* 80:   */   }
/* 81:   */   
/* 82:   */   private static byte[] uncompress(byte[] inputByte)
/* 83:   */     throws Exception
/* 84:   */   {
/* 85:79 */     Inflater inflater = new Inflater();
/* 86:80 */     inflater.setInput(inputByte);
/* 87:81 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/* 88:82 */     byte[] outByte = new byte[1024];
/* 89:   */     try
/* 90:   */     {
/* 91:85 */       while (!inflater.finished())
/* 92:   */       {
/* 93:86 */         int len = inflater.inflate(outByte);
/* 94:87 */         if (len == 0) {
/* 95:   */           break;
/* 96:   */         }
/* 97:90 */         bos.write(outByte, 0, len);
/* 98:   */       }
/* 99:   */     }
/* :0:   */     finally
/* :1:   */     {
/* :2:93 */       inflater.end();
/* :3:94 */       bos.close();
/* :4:   */     }
/* :5:96 */     return bos.toByteArray();
/* :6:   */   }
/* :7:   */ }


/* Location:           F:\thirty\SUNING\统一配置管理（SCM）\snf-scm-client-2.2.0.jar
 * Qualified Name:     com.suning.framework.scm.util.CompressUtils
 * JD-Core Version:    0.7.0.1
 */