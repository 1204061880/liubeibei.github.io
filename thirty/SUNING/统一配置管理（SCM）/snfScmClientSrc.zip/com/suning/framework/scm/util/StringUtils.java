/*   1:    */ package com.suning.framework.scm.util;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.List;
/*   5:    */ 
/*   6:    */ public class StringUtils
/*   7:    */ {
/*   8:    */   private static final String EMPTY_STRING = "";
/*   9:    */   private static final String NULL_STRING = "null";
/*  10:    */   private static final String ARRAY_START = "{";
/*  11:    */   private static final String ARRAY_END = "}";
/*  12:    */   private static final String EMPTY_ARRAY = "{}";
/*  13:    */   private static final String ARRAY_ELEMENT_SEPARATOR = ", ";
/*  14:    */   public static final int INDEX_NOT_FOUND = -1;
/*  15: 18 */   public static final String[] EMPTY_STRING_ARRAY = new String[0];
/*  16:    */   
/*  17:    */   public static String arrayToDelimitedString(Object[] arr, String delim)
/*  18:    */   {
/*  19: 29 */     if (isEmpty(arr)) {
/*  20: 30 */       return "";
/*  21:    */     }
/*  22: 32 */     if (arr.length == 1) {
/*  23: 33 */       return nullSafeToString(arr[0]);
/*  24:    */     }
/*  25: 35 */     StringBuilder sb = new StringBuilder();
/*  26: 36 */     for (int i = 0; i < arr.length; i++)
/*  27:    */     {
/*  28: 37 */       if (i > 0) {
/*  29: 38 */         sb.append(delim);
/*  30:    */       }
/*  31: 40 */       sb.append(arr[i]);
/*  32:    */     }
/*  33: 42 */     return sb.toString();
/*  34:    */   }
/*  35:    */   
/*  36:    */   public static String arrayToCommaDelimitedString(Object[] arr)
/*  37:    */   {
/*  38: 53 */     return arrayToDelimitedString(arr, ",");
/*  39:    */   }
/*  40:    */   
/*  41:    */   public static boolean isEmpty(Object[] array)
/*  42:    */   {
/*  43: 63 */     return (array == null) || (array.length == 0);
/*  44:    */   }
/*  45:    */   
/*  46:    */   public static boolean isEmpty(String str)
/*  47:    */   {
/*  48: 67 */     return (str == null) || (str.length() == 0);
/*  49:    */   }
/*  50:    */   
/*  51:    */   public static String nullSafeToString(Object obj)
/*  52:    */   {
/*  53: 79 */     if (obj == null) {
/*  54: 80 */       return "null";
/*  55:    */     }
/*  56: 82 */     if ((obj instanceof String)) {
/*  57: 83 */       return (String)obj;
/*  58:    */     }
/*  59: 85 */     if ((obj instanceof Object[])) {
/*  60: 86 */       return nullSafeToString((Object[])obj);
/*  61:    */     }
/*  62: 88 */     if ((obj instanceof boolean[])) {
/*  63: 89 */       return nullSafeToString((boolean[])obj);
/*  64:    */     }
/*  65: 91 */     if ((obj instanceof byte[])) {
/*  66: 92 */       return nullSafeToString((byte[])obj);
/*  67:    */     }
/*  68: 94 */     if ((obj instanceof char[])) {
/*  69: 95 */       return nullSafeToString((char[])obj);
/*  70:    */     }
/*  71: 97 */     if ((obj instanceof double[])) {
/*  72: 98 */       return nullSafeToString((double[])obj);
/*  73:    */     }
/*  74:100 */     if ((obj instanceof float[])) {
/*  75:101 */       return nullSafeToString((float[])obj);
/*  76:    */     }
/*  77:103 */     if ((obj instanceof int[])) {
/*  78:104 */       return nullSafeToString((int[])obj);
/*  79:    */     }
/*  80:106 */     if ((obj instanceof long[])) {
/*  81:107 */       return nullSafeToString((long[])obj);
/*  82:    */     }
/*  83:109 */     if ((obj instanceof short[])) {
/*  84:110 */       return nullSafeToString((short[])obj);
/*  85:    */     }
/*  86:112 */     String str = obj.toString();
/*  87:113 */     return str != null ? str : "";
/*  88:    */   }
/*  89:    */   
/*  90:    */   public static String nullSafeToString(Object[] array)
/*  91:    */   {
/*  92:126 */     if (array == null) {
/*  93:127 */       return "null";
/*  94:    */     }
/*  95:129 */     int length = array.length;
/*  96:130 */     if (length == 0) {
/*  97:131 */       return "{}";
/*  98:    */     }
/*  99:133 */     StringBuilder sb = new StringBuilder();
/* 100:134 */     for (int i = 0; i < length; i++)
/* 101:    */     {
/* 102:135 */       if (i == 0) {
/* 103:136 */         sb.append("{");
/* 104:    */       } else {
/* 105:139 */         sb.append(", ");
/* 106:    */       }
/* 107:141 */       sb.append(String.valueOf(array[i]));
/* 108:    */     }
/* 109:143 */     sb.append("}");
/* 110:144 */     return sb.toString();
/* 111:    */   }
/* 112:    */   
/* 113:    */   public static String nullSafeToString(boolean[] array)
/* 114:    */   {
/* 115:157 */     if (array == null) {
/* 116:158 */       return "null";
/* 117:    */     }
/* 118:160 */     int length = array.length;
/* 119:161 */     if (length == 0) {
/* 120:162 */       return "{}";
/* 121:    */     }
/* 122:164 */     StringBuilder sb = new StringBuilder();
/* 123:165 */     for (int i = 0; i < length; i++)
/* 124:    */     {
/* 125:166 */       if (i == 0) {
/* 126:167 */         sb.append("{");
/* 127:    */       } else {
/* 128:170 */         sb.append(", ");
/* 129:    */       }
/* 130:173 */       sb.append(array[i]);
/* 131:    */     }
/* 132:175 */     sb.append("}");
/* 133:176 */     return sb.toString();
/* 134:    */   }
/* 135:    */   
/* 136:    */   public static String nullSafeToString(byte[] array)
/* 137:    */   {
/* 138:189 */     if (array == null) {
/* 139:190 */       return "null";
/* 140:    */     }
/* 141:192 */     int length = array.length;
/* 142:193 */     if (length == 0) {
/* 143:194 */       return "{}";
/* 144:    */     }
/* 145:196 */     StringBuilder sb = new StringBuilder();
/* 146:197 */     for (int i = 0; i < length; i++)
/* 147:    */     {
/* 148:198 */       if (i == 0) {
/* 149:199 */         sb.append("{");
/* 150:    */       } else {
/* 151:202 */         sb.append(", ");
/* 152:    */       }
/* 153:204 */       sb.append(array[i]);
/* 154:    */     }
/* 155:206 */     sb.append("}");
/* 156:207 */     return sb.toString();
/* 157:    */   }
/* 158:    */   
/* 159:    */   public static String nullSafeToString(char[] array)
/* 160:    */   {
/* 161:220 */     if (array == null) {
/* 162:221 */       return "null";
/* 163:    */     }
/* 164:223 */     int length = array.length;
/* 165:224 */     if (length == 0) {
/* 166:225 */       return "{}";
/* 167:    */     }
/* 168:227 */     StringBuilder sb = new StringBuilder();
/* 169:228 */     for (int i = 0; i < length; i++)
/* 170:    */     {
/* 171:229 */       if (i == 0) {
/* 172:230 */         sb.append("{");
/* 173:    */       } else {
/* 174:233 */         sb.append(", ");
/* 175:    */       }
/* 176:235 */       sb.append("'").append(array[i]).append("'");
/* 177:    */     }
/* 178:237 */     sb.append("}");
/* 179:238 */     return sb.toString();
/* 180:    */   }
/* 181:    */   
/* 182:    */   public static String nullSafeToString(double[] array)
/* 183:    */   {
/* 184:251 */     if (array == null) {
/* 185:252 */       return "null";
/* 186:    */     }
/* 187:254 */     int length = array.length;
/* 188:255 */     if (length == 0) {
/* 189:256 */       return "{}";
/* 190:    */     }
/* 191:258 */     StringBuilder sb = new StringBuilder();
/* 192:259 */     for (int i = 0; i < length; i++)
/* 193:    */     {
/* 194:260 */       if (i == 0) {
/* 195:261 */         sb.append("{");
/* 196:    */       } else {
/* 197:264 */         sb.append(", ");
/* 198:    */       }
/* 199:267 */       sb.append(array[i]);
/* 200:    */     }
/* 201:269 */     sb.append("}");
/* 202:270 */     return sb.toString();
/* 203:    */   }
/* 204:    */   
/* 205:    */   public static String nullSafeToString(float[] array)
/* 206:    */   {
/* 207:283 */     if (array == null) {
/* 208:284 */       return "null";
/* 209:    */     }
/* 210:286 */     int length = array.length;
/* 211:287 */     if (length == 0) {
/* 212:288 */       return "{}";
/* 213:    */     }
/* 214:290 */     StringBuilder sb = new StringBuilder();
/* 215:291 */     for (int i = 0; i < length; i++)
/* 216:    */     {
/* 217:292 */       if (i == 0) {
/* 218:293 */         sb.append("{");
/* 219:    */       } else {
/* 220:296 */         sb.append(", ");
/* 221:    */       }
/* 222:299 */       sb.append(array[i]);
/* 223:    */     }
/* 224:301 */     sb.append("}");
/* 225:302 */     return sb.toString();
/* 226:    */   }
/* 227:    */   
/* 228:    */   public static String nullSafeToString(int[] array)
/* 229:    */   {
/* 230:315 */     if (array == null) {
/* 231:316 */       return "null";
/* 232:    */     }
/* 233:318 */     int length = array.length;
/* 234:319 */     if (length == 0) {
/* 235:320 */       return "{}";
/* 236:    */     }
/* 237:322 */     StringBuilder sb = new StringBuilder();
/* 238:323 */     for (int i = 0; i < length; i++)
/* 239:    */     {
/* 240:324 */       if (i == 0) {
/* 241:325 */         sb.append("{");
/* 242:    */       } else {
/* 243:328 */         sb.append(", ");
/* 244:    */       }
/* 245:330 */       sb.append(array[i]);
/* 246:    */     }
/* 247:332 */     sb.append("}");
/* 248:333 */     return sb.toString();
/* 249:    */   }
/* 250:    */   
/* 251:    */   public static String nullSafeToString(long[] array)
/* 252:    */   {
/* 253:346 */     if (array == null) {
/* 254:347 */       return "null";
/* 255:    */     }
/* 256:349 */     int length = array.length;
/* 257:350 */     if (length == 0) {
/* 258:351 */       return "{}";
/* 259:    */     }
/* 260:353 */     StringBuilder sb = new StringBuilder();
/* 261:354 */     for (int i = 0; i < length; i++)
/* 262:    */     {
/* 263:355 */       if (i == 0) {
/* 264:356 */         sb.append("{");
/* 265:    */       } else {
/* 266:359 */         sb.append(", ");
/* 267:    */       }
/* 268:361 */       sb.append(array[i]);
/* 269:    */     }
/* 270:363 */     sb.append("}");
/* 271:364 */     return sb.toString();
/* 272:    */   }
/* 273:    */   
/* 274:    */   public static String nullSafeToString(short[] array)
/* 275:    */   {
/* 276:377 */     if (array == null) {
/* 277:378 */       return "null";
/* 278:    */     }
/* 279:380 */     int length = array.length;
/* 280:381 */     if (length == 0) {
/* 281:382 */       return "{}";
/* 282:    */     }
/* 283:384 */     StringBuilder sb = new StringBuilder();
/* 284:385 */     for (int i = 0; i < length; i++)
/* 285:    */     {
/* 286:386 */       if (i == 0) {
/* 287:387 */         sb.append("{");
/* 288:    */       } else {
/* 289:390 */         sb.append(", ");
/* 290:    */       }
/* 291:392 */       sb.append(array[i]);
/* 292:    */     }
/* 293:394 */     sb.append("}");
/* 294:395 */     return sb.toString();
/* 295:    */   }
/* 296:    */   
/* 297:    */   public static String substringAfter(String str, String separator)
/* 298:    */   {
/* 299:399 */     if (isEmpty(str)) {
/* 300:400 */       return str;
/* 301:    */     }
/* 302:402 */     if (separator == null) {
/* 303:403 */       return "";
/* 304:    */     }
/* 305:405 */     int pos = str.indexOf(separator);
/* 306:406 */     if (pos == -1) {
/* 307:407 */       return "";
/* 308:    */     }
/* 309:409 */     return str.substring(pos + separator.length());
/* 310:    */   }
/* 311:    */   
/* 312:    */   public static String substringAfterLast(String str, String separator)
/* 313:    */   {
/* 314:413 */     if (isEmpty(str)) {
/* 315:414 */       return str;
/* 316:    */     }
/* 317:416 */     if (isEmpty(separator)) {
/* 318:417 */       return "";
/* 319:    */     }
/* 320:419 */     int pos = str.lastIndexOf(separator);
/* 321:420 */     if ((pos == -1) || (pos == str.length() - separator.length())) {
/* 322:421 */       return "";
/* 323:    */     }
/* 324:423 */     return str.substring(pos + separator.length());
/* 325:    */   }
/* 326:    */   
/* 327:    */   public static String substringBefore(String str, String separator)
/* 328:    */   {
/* 329:427 */     if ((isEmpty(str)) || (separator == null)) {
/* 330:428 */       return str;
/* 331:    */     }
/* 332:430 */     if (separator.length() == 0) {
/* 333:431 */       return "";
/* 334:    */     }
/* 335:433 */     int pos = str.indexOf(separator);
/* 336:434 */     if (pos == -1) {
/* 337:435 */       return str;
/* 338:    */     }
/* 339:437 */     return str.substring(0, pos);
/* 340:    */   }
/* 341:    */   
/* 342:    */   public static String substringBeforeLast(String str, String separator)
/* 343:    */   {
/* 344:441 */     if ((isEmpty(str)) || (isEmpty(separator))) {
/* 345:442 */       return str;
/* 346:    */     }
/* 347:444 */     int pos = str.lastIndexOf(separator);
/* 348:445 */     if (pos == -1) {
/* 349:446 */       return str;
/* 350:    */     }
/* 351:448 */     return str.substring(0, pos);
/* 352:    */   }
/* 353:    */   
/* 354:    */   public static String replace(String text, String searchString, String replacement)
/* 355:    */   {
/* 356:452 */     return replace(text, searchString, replacement, -1);
/* 357:    */   }
/* 358:    */   
/* 359:    */   public static String replace(String text, String searchString, String replacement, int max)
/* 360:    */   {
/* 361:456 */     if ((isEmpty(text)) || (isEmpty(searchString)) || (replacement == null) || (max == 0)) {
/* 362:457 */       return text;
/* 363:    */     }
/* 364:459 */     int start = 0;
/* 365:460 */     int end = text.indexOf(searchString, start);
/* 366:461 */     if (end == -1) {
/* 367:462 */       return text;
/* 368:    */     }
/* 369:464 */     int replLength = searchString.length();
/* 370:465 */     int increase = replacement.length() - replLength;
/* 371:466 */     increase = increase < 0 ? 0 : increase;
/* 372:467 */     increase *= (max > 64 ? 64 : max < 0 ? 16 : max);
/* 373:468 */     StringBuilder buf = new StringBuilder(text.length() + increase);
/* 374:469 */     while (end != -1)
/* 375:    */     {
/* 376:470 */       buf.append(text.substring(start, end)).append(replacement);
/* 377:471 */       start = end + replLength;
/* 378:472 */       max--;
/* 379:472 */       if (max == 0) {
/* 380:    */         break;
/* 381:    */       }
/* 382:475 */       end = text.indexOf(searchString, start);
/* 383:    */     }
/* 384:477 */     buf.append(text.substring(start));
/* 385:478 */     return buf.toString();
/* 386:    */   }
/* 387:    */   
/* 388:    */   public static String join(Object[] array, char separator)
/* 389:    */   {
/* 390:482 */     if (array == null) {
/* 391:483 */       return null;
/* 392:    */     }
/* 393:485 */     return join(array, separator, 0, array.length);
/* 394:    */   }
/* 395:    */   
/* 396:    */   public static String join(Object[] array, String separator)
/* 397:    */   {
/* 398:489 */     if (array == null) {
/* 399:490 */       return null;
/* 400:    */     }
/* 401:492 */     return join(array, separator, 0, array.length);
/* 402:    */   }
/* 403:    */   
/* 404:    */   public static String join(Object[] array, String separator, int startIndex, int endIndex)
/* 405:    */   {
/* 406:496 */     if (array == null) {
/* 407:497 */       return null;
/* 408:    */     }
/* 409:499 */     if (separator == null) {
/* 410:500 */       separator = "";
/* 411:    */     }
/* 412:504 */     int noOfItems = endIndex - startIndex;
/* 413:505 */     if (noOfItems <= 0) {
/* 414:506 */       return "";
/* 415:    */     }
/* 416:508 */     StringBuilder buf = new StringBuilder(noOfItems * 16);
/* 417:509 */     for (int i = startIndex; i < endIndex; i++)
/* 418:    */     {
/* 419:510 */       if (i > startIndex) {
/* 420:511 */         buf.append(separator);
/* 421:    */       }
/* 422:513 */       if (array[i] != null) {
/* 423:514 */         buf.append(array[i]);
/* 424:    */       }
/* 425:    */     }
/* 426:517 */     return buf.toString();
/* 427:    */   }
/* 428:    */   
/* 429:    */   public static String join(Object[] array, char separator, int startIndex, int endIndex)
/* 430:    */   {
/* 431:521 */     if (array == null) {
/* 432:522 */       return null;
/* 433:    */     }
/* 434:524 */     int noOfItems = endIndex - startIndex;
/* 435:525 */     if (noOfItems <= 0) {
/* 436:526 */       return "";
/* 437:    */     }
/* 438:528 */     StringBuilder buf = new StringBuilder(noOfItems * 16);
/* 439:529 */     for (int i = startIndex; i < endIndex; i++)
/* 440:    */     {
/* 441:530 */       if (i > startIndex) {
/* 442:531 */         buf.append(separator);
/* 443:    */       }
/* 444:533 */       if (array[i] != null) {
/* 445:534 */         buf.append(array[i]);
/* 446:    */       }
/* 447:    */     }
/* 448:537 */     return buf.toString();
/* 449:    */   }
/* 450:    */   
/* 451:    */   public static String[] split(String str, String separatorChars)
/* 452:    */   {
/* 453:566 */     return splitWorker(str, separatorChars, -1, false);
/* 454:    */   }
/* 455:    */   
/* 456:    */   private static String[] splitWorker(String str, String separatorChars, int max, boolean preserveAllTokens)
/* 457:    */   {
/* 458:588 */     if (str == null) {
/* 459:589 */       return null;
/* 460:    */     }
/* 461:591 */     int len = str.length();
/* 462:592 */     if (len == 0) {
/* 463:593 */       return EMPTY_STRING_ARRAY;
/* 464:    */     }
/* 465:595 */     List list = new ArrayList();
/* 466:596 */     int sizePlus1 = 1;
/* 467:597 */     int i = 0;int start = 0;
/* 468:598 */     boolean match = false;
/* 469:599 */     boolean lastMatch = false;
/* 470:600 */     if (separatorChars == null) {
/* 471:602 */       while (i < len) {
/* 472:603 */         if (Character.isWhitespace(str.charAt(i)))
/* 473:    */         {
/* 474:604 */           if ((match) || (preserveAllTokens))
/* 475:    */           {
/* 476:605 */             lastMatch = true;
/* 477:606 */             if (sizePlus1++ == max)
/* 478:    */             {
/* 479:607 */               i = len;
/* 480:608 */               lastMatch = false;
/* 481:    */             }
/* 482:610 */             list.add(str.substring(start, i));
/* 483:611 */             match = false;
/* 484:    */           }
/* 485:613 */           i++;start = i;
/* 486:    */         }
/* 487:    */         else
/* 488:    */         {
/* 489:616 */           lastMatch = false;
/* 490:617 */           match = true;
/* 491:618 */           i++;
/* 492:    */         }
/* 493:    */       }
/* 494:    */     }
/* 495:620 */     if (separatorChars.length() == 1)
/* 496:    */     {
/* 497:622 */       char sep = separatorChars.charAt(0);
/* 498:623 */       while (i < len) {
/* 499:624 */         if (str.charAt(i) == sep)
/* 500:    */         {
/* 501:625 */           if ((match) || (preserveAllTokens))
/* 502:    */           {
/* 503:626 */             lastMatch = true;
/* 504:627 */             if (sizePlus1++ == max)
/* 505:    */             {
/* 506:628 */               i = len;
/* 507:629 */               lastMatch = false;
/* 508:    */             }
/* 509:631 */             list.add(str.substring(start, i));
/* 510:632 */             match = false;
/* 511:    */           }
/* 512:634 */           i++;start = i;
/* 513:    */         }
/* 514:    */         else
/* 515:    */         {
/* 516:637 */           lastMatch = false;
/* 517:638 */           match = true;
/* 518:639 */           i++;
/* 519:    */         }
/* 520:    */       }
/* 521:    */     }
/* 522:    */     else
/* 523:    */     {
/* 524:643 */       while (i < len) {
/* 525:644 */         if (separatorChars.indexOf(str.charAt(i)) >= 0)
/* 526:    */         {
/* 527:645 */           if ((match) || (preserveAllTokens))
/* 528:    */           {
/* 529:646 */             lastMatch = true;
/* 530:647 */             if (sizePlus1++ == max)
/* 531:    */             {
/* 532:648 */               i = len;
/* 533:649 */               lastMatch = false;
/* 534:    */             }
/* 535:651 */             list.add(str.substring(start, i));
/* 536:652 */             match = false;
/* 537:    */           }
/* 538:654 */           i++;start = i;
/* 539:    */         }
/* 540:    */         else
/* 541:    */         {
/* 542:657 */           lastMatch = false;
/* 543:658 */           match = true;
/* 544:659 */           i++;
/* 545:    */         }
/* 546:    */       }
/* 547:    */     }
/* 548:662 */     if ((match) || ((preserveAllTokens) && (lastMatch))) {
/* 549:663 */       list.add(str.substring(start, i));
/* 550:    */     }
/* 551:665 */     return (String[])list.toArray(new String[list.size()]);
/* 552:    */   }
/* 553:    */ }


/* Location:           F:\thirty\SUNING\统一配置管理（SCM）\snf-scm-client-2.2.0.jar
 * Qualified Name:     com.suning.framework.scm.util.StringUtils
 * JD-Core Version:    0.7.0.1
 */