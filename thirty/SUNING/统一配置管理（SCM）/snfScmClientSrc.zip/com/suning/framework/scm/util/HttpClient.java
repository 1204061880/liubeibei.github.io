/*   1:    */ package com.suning.framework.scm.util;
/*   2:    */ 
/*   3:    */ import java.io.BufferedReader;
/*   4:    */ import java.io.DataOutputStream;
/*   5:    */ import java.io.IOException;
/*   6:    */ import java.io.InputStream;
/*   7:    */ import java.io.InputStreamReader;
/*   8:    */ import java.net.HttpURLConnection;
/*   9:    */ import java.net.Proxy;
/*  10:    */ import java.net.URL;
/*  11:    */ import java.net.URLConnection;
/*  12:    */ import java.util.logging.Level;
/*  13:    */ import java.util.logging.Logger;
/*  14:    */ import java.util.zip.GZIPInputStream;
/*  15:    */ 
/*  16:    */ public abstract class HttpClient
/*  17:    */ {
/*  18: 39 */   protected static final Logger LOG = Logger.getLogger(HttpClient.class.getName());
/*  19:    */   public static final String CONTENT_TYPE_JSON = "application/json";
/*  20:    */   public static final String CONTENT_TYPE_FORM = "application/x-www-form-urlencoded";
/*  21:    */   private static final String HTTP_METHOD_POST = "POST";
/*  22:    */   private static final String HTTP_HEADER_CONTENT_TYPE = "Content-Type";
/*  23:    */   private static final String HTTP_HEADER_CONTENT_LENGTH = "Content-Length";
/*  24:    */   private static final String HTTP_HEADER_CONTENT_ENCODING = "Content-Encoding";
/*  25:    */   private static final String ENCODING_GZIP = "gzip";
/*  26:    */   private static final boolean FOLLOW_REDIRECTS = true;
/*  27:    */   
/*  28:    */   public static String sendByPost(String url, String json, int timeout, int retry, int interval)
/*  29:    */     throws Exception
/*  30:    */   {
/*  31: 96 */     Exception exception = null;
/*  32: 97 */     for (int i = 0; i < retry; i++)
/*  33:    */     {
/*  34:    */       try
/*  35:    */       {
/*  36:100 */         URLConnection connection = new URL(url).openConnection(Proxy.NO_PROXY);
/*  37:102 */         if (!(connection instanceof HttpURLConnection))
/*  38:    */         {
/*  39:103 */           exception = new Exception("Service URL [" + url + "] is not an HTTP URL");
/*  40:104 */           break;
/*  41:    */         }
/*  42:106 */         HttpURLConnection con = (HttpURLConnection)connection;
/*  43:    */         
/*  44:108 */         prepareConnection(con, json.length(), timeout);
/*  45:    */         
/*  46:110 */         writeRequestBody(con, json);
/*  47:    */         
/*  48:112 */         validateResponse(con);
/*  49:    */         
/*  50:114 */         InputStream responseBody = readResponseBody(con);
/*  51:    */         
/*  52:116 */         return readResult(responseBody);
/*  53:    */       }
/*  54:    */       catch (Exception ex)
/*  55:    */       {
/*  56:118 */         exception = ex;
/*  57:120 */         if ((ex instanceof IOException)) {
/*  58:    */           break label130;
/*  59:    */         }
/*  60:    */       }
/*  61:121 */       break;
/*  62:    */       label130:
/*  63:124 */       if (interval > 0) {
/*  64:125 */         Thread.sleep(interval);
/*  65:    */       }
/*  66:    */     }
/*  67:129 */     throw exception;
/*  68:    */   }
/*  69:    */   
/*  70:    */   private static void prepareConnection(HttpURLConnection connection, int contentLength, int timeout)
/*  71:    */     throws IOException
/*  72:    */   {
/*  73:146 */     if (timeout >= 0) {
/*  74:147 */       connection.setConnectTimeout(timeout);
/*  75:    */     }
/*  76:150 */     if (timeout >= 0) {
/*  77:151 */       connection.setReadTimeout(timeout);
/*  78:    */     }
/*  79:154 */     connection.setInstanceFollowRedirects(true);
/*  80:    */     
/*  81:156 */     connection.setDoOutput(true);
/*  82:    */     
/*  83:158 */     connection.setRequestMethod("POST");
/*  84:    */     
/*  85:160 */     connection.setDoInput(true);
/*  86:    */     
/*  87:162 */     connection.setUseCaches(false);
/*  88:    */     
/*  89:164 */     connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
/*  90:165 */     connection.setRequestProperty("Content-Length", Integer.toString(contentLength));
/*  91:    */   }
/*  92:    */   
/*  93:    */   private static void writeRequestBody(HttpURLConnection con, String data)
/*  94:    */     throws IOException
/*  95:    */   {
/*  96:179 */     DataOutputStream printout = new DataOutputStream(con.getOutputStream());
/*  97:180 */     printout.write(data.getBytes("UTF-8"));
/*  98:    */     
/*  99:182 */     printout.flush();
/* 100:    */     
/* 101:184 */     printout.close();
/* 102:    */   }
/* 103:    */   
/* 104:    */   private static void validateResponse(HttpURLConnection con)
/* 105:    */     throws Exception
/* 106:    */   {
/* 107:198 */     if (con.getResponseCode() == 503)
/* 108:    */     {
/* 109:199 */       String errorMsg = con.getHeaderField("errorCode");
/* 110:201 */       if ((errorMsg != null) && (errorMsg.length() > 0))
/* 111:    */       {
/* 112:202 */         LOG.log(Level.WARNING, "Server handle meet error! Error Message is:" + errorMsg);
/* 113:203 */         throw new RuntimeException(errorMsg);
/* 114:    */       }
/* 115:206 */       LOG.log(Level.INFO, "Server handle meet error!");
/* 116:207 */       throw new RuntimeException("Server handle meet error!");
/* 117:    */     }
/* 118:211 */     if (con.getResponseCode() >= 300)
/* 119:    */     {
/* 120:212 */       LOG.log(Level.WARNING, "Did not receive successful HTTP response: status code = " + con.getResponseCode() + ", status message = [" + con.getResponseMessage() + "]");
/* 121:    */       
/* 122:214 */       throw new IOException("Did not receive successful HTTP response: status code = " + con.getResponseCode() + ", status message = [" + con.getResponseMessage() + "]");
/* 123:    */     }
/* 124:    */   }
/* 125:    */   
/* 126:    */   private static InputStream readResponseBody(HttpURLConnection con)
/* 127:    */     throws IOException
/* 128:    */   {
/* 129:230 */     if (isGzipResponse(con)) {
/* 130:232 */       return new GZIPInputStream(con.getInputStream());
/* 131:    */     }
/* 132:235 */     return con.getInputStream();
/* 133:    */   }
/* 134:    */   
/* 135:    */   private static boolean isGzipResponse(HttpURLConnection con)
/* 136:    */   {
/* 137:249 */     String encodingHeader = con.getHeaderField("Content-Encoding");
/* 138:250 */     return (encodingHeader != null) && (encodingHeader.toLowerCase().contains("gzip"));
/* 139:    */   }
/* 140:    */   
/* 141:    */   private static String readResult(InputStream is)
/* 142:    */     throws IOException, ClassNotFoundException
/* 143:    */   {
/* 144:265 */     BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
/* 145:    */     try
/* 146:    */     {
/* 147:268 */       StringBuilder temp = new StringBuilder();
/* 148:269 */       String line = reader.readLine();
/* 149:271 */       while (line != null)
/* 150:    */       {
/* 151:272 */         temp.append(line);
/* 152:273 */         line = reader.readLine();
/* 153:    */       }
/* 154:275 */       return temp.toString();
/* 155:    */     }
/* 156:    */     finally
/* 157:    */     {
/* 158:277 */       reader.close();
/* 159:    */     }
/* 160:    */   }
/* 161:    */ }


/* Location:           F:\thirty\SUNING\统一配置管理（SCM）\snf-scm-client-2.2.0.jar
 * Qualified Name:     com.suning.framework.scm.util.HttpClient
 * JD-Core Version:    0.7.0.1
 */