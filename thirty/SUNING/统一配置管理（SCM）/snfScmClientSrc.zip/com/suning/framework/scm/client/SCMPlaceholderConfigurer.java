/*   1:    */ package com.suning.framework.scm.client;
/*   2:    */ 
/*   3:    */ import java.io.IOException;
/*   4:    */ import java.io.StringReader;
/*   5:    */ import java.util.Enumeration;
/*   6:    */ import java.util.Properties;
/*   7:    */ import java.util.Set;
/*   8:    */ import org.apache.commons.logging.Log;
/*   9:    */ import org.springframework.beans.BeansException;
/*  10:    */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*  11:    */ import org.springframework.beans.factory.config.PlaceholderConfigurerSupport;
/*  12:    */ import org.springframework.core.Constants;
/*  13:    */ import org.springframework.util.ObjectUtils;
/*  14:    */ import org.springframework.util.PropertyPlaceholderHelper;
/*  15:    */ import org.springframework.util.PropertyPlaceholderHelper.PlaceholderResolver;
/*  16:    */ import org.springframework.util.StringValueResolver;
/*  17:    */ 
/*  18:    */ public class SCMPlaceholderConfigurer
/*  19:    */   extends PlaceholderConfigurerSupport
/*  20:    */ {
/*  21:    */   public static final int SYSTEM_PROPERTIES_MODE_NEVER = 0;
/*  22:    */   public static final int SYSTEM_PROPERTIES_MODE_FALLBACK = 1;
/*  23:    */   public static final int SYSTEM_PROPERTIES_MODE_OVERRIDE = 2;
/*  24: 91 */   private static final Constants constants = new Constants(SCMPlaceholderConfigurer.class);
/*  25:    */   private int systemPropertiesMode;
/*  26:    */   private boolean searchSystemEnvironment;
/*  27:    */   private String scmPath;
/*  28:    */   
/*  29:    */   public SCMPlaceholderConfigurer()
/*  30:    */   {
/*  31: 93 */     this.systemPropertiesMode = 1;
/*  32:    */     
/*  33: 95 */     this.searchSystemEnvironment = true;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public void setSystemPropertiesModeName(String constantName)
/*  37:    */     throws IllegalArgumentException
/*  38:    */   {
/*  39:109 */     this.systemPropertiesMode = constants.asNumber(constantName).intValue();
/*  40:    */   }
/*  41:    */   
/*  42:    */   public void setSystemPropertiesMode(int systemPropertiesMode)
/*  43:    */   {
/*  44:126 */     this.systemPropertiesMode = systemPropertiesMode;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public void setSearchSystemEnvironment(boolean searchSystemEnvironment)
/*  48:    */   {
/*  49:149 */     this.searchSystemEnvironment = searchSystemEnvironment;
/*  50:    */   }
/*  51:    */   
/*  52:    */   protected String resolvePlaceholder(String placeholder, Properties props, int systemPropertiesMode)
/*  53:    */   {
/*  54:170 */     String propVal = null;
/*  55:171 */     if (systemPropertiesMode == 2) {
/*  56:172 */       propVal = resolveSystemProperty(placeholder);
/*  57:    */     }
/*  58:174 */     if (propVal == null) {
/*  59:175 */       propVal = resolvePlaceholder(placeholder, props);
/*  60:    */     }
/*  61:177 */     if ((propVal == null) && (systemPropertiesMode == 1)) {
/*  62:178 */       propVal = resolveSystemProperty(placeholder);
/*  63:    */     }
/*  64:180 */     return propVal;
/*  65:    */   }
/*  66:    */   
/*  67:    */   protected String resolvePlaceholder(String placeholder, Properties props)
/*  68:    */   {
/*  69:198 */     return props.getProperty(placeholder);
/*  70:    */   }
/*  71:    */   
/*  72:    */   protected String resolveSystemProperty(String key)
/*  73:    */   {
/*  74:    */     try
/*  75:    */     {
/*  76:213 */       String value = System.getProperty(key);
/*  77:214 */       if ((value == null) && (this.searchSystemEnvironment)) {}
/*  78:215 */       return System.getenv(key);
/*  79:    */     }
/*  80:    */     catch (Throwable ex)
/*  81:    */     {
/*  82:219 */       if (this.logger.isDebugEnabled()) {
/*  83:220 */         this.logger.debug("Could not access system property '" + key + "': " + ex);
/*  84:    */       }
/*  85:    */     }
/*  86:222 */     return null;
/*  87:    */   }
/*  88:    */   
/*  89:    */   protected void convertProperties(Properties props)
/*  90:    */   {
/*  91:236 */     Enumeration<?> propertyNames = props.propertyNames();
/*  92:237 */     while (propertyNames.hasMoreElements())
/*  93:    */     {
/*  94:238 */       String propertyName = (String)propertyNames.nextElement();
/*  95:239 */       String propertyValue = props.getProperty(propertyName);
/*  96:240 */       String convertedValue = convertProperty(propertyName, propertyValue);
/*  97:241 */       if (!ObjectUtils.nullSafeEquals(propertyValue, convertedValue)) {
/*  98:242 */         props.setProperty(propertyName, convertedValue);
/*  99:    */       }
/* 100:    */     }
/* 101:    */   }
/* 102:    */   
/* 103:    */   protected void processProperties(ConfigurableListableBeanFactory beanFactoryToProcess, Properties props)
/* 104:    */     throws BeansException
/* 105:    */   {
/* 106:254 */     Properties properties = new Properties();
/* 107:255 */     SCMClient scmClient = SCMClientImpl.getInstance();
/* 108:256 */     SCMNode node = scmClient.getConfig(this.scmPath);
/* 109:257 */     node.sync();
/* 110:258 */     String configInfo = node.getValue();
/* 111:259 */     if ((configInfo == null) || ("".equals(configInfo))) {
/* 112:260 */       throw new SCMException("get scm config path:" + this.scmPath + " is null!");
/* 113:    */     }
/* 114:262 */     StringReader stringReader = new StringReader(configInfo);
/* 115:    */     try
/* 116:    */     {
/* 117:264 */       properties.load(stringReader);
/* 118:    */     }
/* 119:    */     catch (IOException e)
/* 120:    */     {
/* 121:266 */       this.logger.error(e);
/* 122:    */     }
/* 123:268 */     StringValueResolver valueResolver = new PlaceholderResolvingStringValueResolver(properties);
/* 124:269 */     doProcessProperties(beanFactoryToProcess, valueResolver);
/* 125:    */   }
/* 126:    */   
/* 127:    */   @Deprecated
/* 128:    */   protected String parseStringValue(String strVal, Properties props, Set<?> visitedPlaceholders)
/* 129:    */   {
/* 130:286 */     PropertyPlaceholderHelper helper = new PropertyPlaceholderHelper(this.placeholderPrefix, this.placeholderSuffix, this.valueSeparator, this.ignoreUnresolvablePlaceholders);
/* 131:    */     
/* 132:288 */     PropertyPlaceholderHelper.PlaceholderResolver resolver = new PropertyPlaceholderConfigurerResolver(props, null);
/* 133:289 */     return helper.replacePlaceholders(strVal, resolver);
/* 134:    */   }
/* 135:    */   
/* 136:    */   private class PlaceholderResolvingStringValueResolver
/* 137:    */     implements StringValueResolver
/* 138:    */   {
/* 139:    */     private final PropertyPlaceholderHelper helper;
/* 140:    */     private final PropertyPlaceholderHelper.PlaceholderResolver resolver;
/* 141:    */     
/* 142:    */     public PlaceholderResolvingStringValueResolver(Properties props)
/* 143:    */     {
/* 144:300 */       this.helper = new PropertyPlaceholderHelper(SCMPlaceholderConfigurer.this.placeholderPrefix, SCMPlaceholderConfigurer.this.placeholderSuffix, SCMPlaceholderConfigurer.this.valueSeparator, SCMPlaceholderConfigurer.this.ignoreUnresolvablePlaceholders);
/* 145:    */       
/* 146:302 */       this.resolver = new SCMPlaceholderConfigurer.PropertyPlaceholderConfigurerResolver(SCMPlaceholderConfigurer.this, props, null);
/* 147:    */     }
/* 148:    */     
/* 149:    */     public String resolveStringValue(String strVal)
/* 150:    */       throws BeansException
/* 151:    */     {
/* 152:306 */       String value = this.helper.replacePlaceholders(strVal, this.resolver);
/* 153:307 */       return value.equals(SCMPlaceholderConfigurer.this.nullValue) ? null : value;
/* 154:    */     }
/* 155:    */   }
/* 156:    */   
/* 157:    */   private class PropertyPlaceholderConfigurerResolver
/* 158:    */     implements PropertyPlaceholderHelper.PlaceholderResolver
/* 159:    */   {
/* 160:    */     private final Properties props;
/* 161:    */     
/* 162:    */     private PropertyPlaceholderConfigurerResolver(Properties props)
/* 163:    */     {
/* 164:317 */       this.props = props;
/* 165:    */     }
/* 166:    */     
/* 167:    */     public String resolvePlaceholder(String placeholderName)
/* 168:    */     {
/* 169:321 */       return SCMPlaceholderConfigurer.this.resolvePlaceholder(placeholderName, this.props, SCMPlaceholderConfigurer.this.systemPropertiesMode);
/* 170:    */     }
/* 171:    */   }
/* 172:    */   
/* 173:    */   public String getScmPath()
/* 174:    */   {
/* 175:327 */     return this.scmPath;
/* 176:    */   }
/* 177:    */   
/* 178:    */   public void setScmPath(String scmPath)
/* 179:    */   {
/* 180:331 */     this.scmPath = scmPath;
/* 181:    */   }
/* 182:    */ }


/* Location:           F:\thirty\SUNING\统一配置管理（SCM）\snf-scm-client-2.2.0.jar
 * Qualified Name:     com.suning.framework.scm.client.SCMPlaceholderConfigurer
 * JD-Core Version:    0.7.0.1
 */