/*   1:    */ package com.suning.framework.scm.util;
/*   2:    */ 
/*   3:    */ import java.io.UnsupportedEncodingException;
/*   4:    */ import java.lang.reflect.Array;
/*   5:    */ import java.net.URLEncoder;
/*   6:    */ import java.util.ArrayList;
/*   7:    */ import java.util.Collection;
/*   8:    */ import java.util.Collections;
/*   9:    */ import java.util.Comparator;
/*  10:    */ import java.util.HashMap;
/*  11:    */ import java.util.HashSet;
/*  12:    */ import java.util.List;
/*  13:    */ import java.util.Map;
/*  14:    */ import java.util.Map.Entry;
/*  15:    */ import java.util.Set;
/*  16:    */ 
/*  17:    */ public class ParamUtil
/*  18:    */ {
/*  19: 39 */   private static final Set<Class> BASEDATATYPE = new HashSet() {};
/*  20:    */   
/*  21:    */   public static String getParamFromMap(Map<String, Object> map)
/*  22:    */   {
/*  23: 71 */     if (map == null) {
/*  24: 72 */       throw new IllegalArgumentException("map is null!");
/*  25:    */     }
/*  26: 75 */     List<Map.Entry<String, Object>> mappingList = new ArrayList(map.entrySet());
/*  27:    */     
/*  28: 77 */     Collections.sort(mappingList, new Comparator()
/*  29:    */     {
/*  30:    */       public int compare(Map.Entry<String, Object> entry1, Map.Entry<String, Object> entry2)
/*  31:    */       {
/*  32: 80 */         return ((String)entry1.getKey()).compareTo((String)entry2.getKey());
/*  33:    */       }
/*  34: 83 */     });
/*  35: 84 */     StringBuilder builder = new StringBuilder();
/*  36: 85 */     for (Map.Entry<String, Object> entry : mappingList)
/*  37:    */     {
/*  38: 86 */       Object obj = entry.getValue();
/*  39: 88 */       if (BASEDATATYPE.contains(obj.getClass()))
/*  40:    */       {
/*  41: 89 */         builder.append((String)entry.getKey()).append("=").append(obj).append("&");
/*  42:    */       }
/*  43: 91 */       else if (obj.getClass().isArray())
/*  44:    */       {
/*  45: 93 */         int arrLength = Array.getLength(obj);
/*  46: 95 */         if (arrLength > 0) {
/*  47: 96 */           for (int i = 0; i < arrLength; i++) {
/*  48: 98 */             builder.append((String)entry.getKey()).append("=").append(Array.get(obj, i)).append("&");
/*  49:    */           }
/*  50:    */         }
/*  51:    */       }
/*  52:102 */       else if ((obj instanceof Collection))
/*  53:    */       {
/*  54:104 */         Collection collection = (Collection)obj;
/*  55:106 */         if (collection.size() > 0) {
/*  56:107 */           for (Object o : collection) {
/*  57:109 */             builder.append((String)entry.getKey()).append("=").append(o).append("&");
/*  58:    */           }
/*  59:    */         }
/*  60:    */       }
/*  61:    */       else
/*  62:    */       {
/*  63:114 */         throw new RuntimeException("Can't parse complex Object:" + obj.getClass());
/*  64:    */       }
/*  65:    */     }
/*  66:118 */     builder.deleteCharAt(builder.lastIndexOf("&"));
/*  67:    */     
/*  68:120 */     return builder.toString();
/*  69:    */   }
/*  70:    */   
/*  71:    */   public static String getEncodedParamFromMap(Map<String, Object> map)
/*  72:    */     throws UnsupportedEncodingException
/*  73:    */   {
/*  74:136 */     if (map == null) {
/*  75:137 */       throw new IllegalArgumentException("map is null!");
/*  76:    */     }
/*  77:140 */     Map<String, Object> encodedMap = new HashMap();
/*  78:141 */     for (Map.Entry<String, Object> entry : map.entrySet())
/*  79:    */     {
/*  80:142 */       Object obj = entry.getValue();
/*  81:144 */       if ((obj instanceof String))
/*  82:    */       {
/*  83:145 */         encodedMap.put(entry.getKey(), URLEncoder.encode((String)obj, "UTF-8"));
/*  84:    */       }
/*  85:147 */       else if (obj.getClass().isArray())
/*  86:    */       {
/*  87:149 */         int arrLength = Array.getLength(obj);
/*  88:150 */         Object[] arr = new Object[arrLength];
/*  89:151 */         for (int i = 0; i < arrLength; i++) {
/*  90:153 */           if ((Array.get(obj, i) instanceof String)) {
/*  91:154 */             arr[i] = URLEncoder.encode((String)Array.get(obj, i), "UTF-8");
/*  92:    */           } else {
/*  93:156 */             arr[i] = Array.get(obj, i);
/*  94:    */           }
/*  95:    */         }
/*  96:160 */         encodedMap.put(entry.getKey(), arr);
/*  97:    */       }
/*  98:162 */       else if ((obj instanceof Collection))
/*  99:    */       {
/* 100:163 */         Collection collection = (Collection)obj;
/* 101:    */         
/* 102:165 */         int arrLength = collection.size();
/* 103:166 */         Object[] arr = new Object[arrLength];
/* 104:167 */         int i = 0;
/* 105:168 */         for (Object o : collection)
/* 106:    */         {
/* 107:170 */           if ((o instanceof String)) {
/* 108:172 */             arr[i] = URLEncoder.encode((String)o, "UTF-8");
/* 109:    */           } else {
/* 110:174 */             arr[i] = o;
/* 111:    */           }
/* 112:176 */           i++;
/* 113:    */         }
/* 114:179 */         encodedMap.put(entry.getKey(), arr);
/* 115:    */       }
/* 116:    */       else
/* 117:    */       {
/* 118:181 */         encodedMap.put(entry.getKey(), obj);
/* 119:    */       }
/* 120:    */     }
/* 121:184 */     return getParamFromMap(encodedMap);
/* 122:    */   }
/* 123:    */ }


/* Location:           F:\thirty\SUNING\统一配置管理（SCM）\snf-scm-client-2.2.0.jar
 * Qualified Name:     com.suning.framework.scm.util.ParamUtil
 * JD-Core Version:    0.7.0.1
 */