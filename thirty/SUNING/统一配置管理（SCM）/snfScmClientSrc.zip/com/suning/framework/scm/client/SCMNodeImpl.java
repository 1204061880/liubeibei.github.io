/*   1:    */ package com.suning.framework.scm.client;
/*   2:    */ 
/*   3:    */ import com.suning.framework.scm.util.MD5Utils;
/*   4:    */ import com.suning.framework.scm.util.ServerNameGetter;
/*   5:    */ import com.suning.framework.scm.util.StringUtils;
/*   6:    */ import com.suning.framework.zookeeper.DataListener;
/*   7:    */ import com.suning.framework.zookeeper.ZkNode;
/*   8:    */ import com.suning.framework.zookeeper.exception.DataException;
/*   9:    */ import java.io.BufferedOutputStream;
/*  10:    */ import java.io.BufferedWriter;
/*  11:    */ import java.io.File;
/*  12:    */ import java.io.FileInputStream;
/*  13:    */ import java.io.FileOutputStream;
/*  14:    */ import java.io.IOException;
/*  15:    */ import java.io.OutputStreamWriter;
/*  16:    */ import java.io.PrintWriter;
/*  17:    */ import java.util.regex.Matcher;
/*  18:    */ import java.util.regex.Pattern;
/*  19:    */ import java.util.regex.PatternSyntaxException;
/*  20:    */ import org.slf4j.Logger;
/*  21:    */ import org.slf4j.LoggerFactory;
/*  22:    */ 
/*  23:    */ public class SCMNodeImpl
/*  24:    */   implements SCMNode, DataListener<String>
/*  25:    */ {
/*  26: 22 */   private static Logger logger = LoggerFactory.getLogger(SCMNodeImpl.class);
/*  27:    */   private static final String SYNC_FAIL = "_SCM_SYNC_FAIL_";
/*  28: 24 */   private static final String PATH_SEPARATOR = File.separator;
/*  29:    */   private String path;
/*  30:    */   private ZkNode<String> zkNode;
/*  31:    */   private volatile String value;
/*  32:    */   private SCMConfiguration configuration;
/*  33:    */   private static final String FILE_SEPARATOR = "-";
/*  34:    */   
/*  35:    */   public SCMNodeImpl(SCMConfiguration configuration, String path, ZkNode<String> zkNode)
/*  36:    */   {
/*  37: 32 */     this.path = path;
/*  38: 33 */     this.zkNode = zkNode;
/*  39: 34 */     this.configuration = configuration;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public void dataChanged(String oldData, String newData)
/*  43:    */   {
/*  44: 39 */     this.value = newData;
/*  45: 40 */     saveToLocalFileCache(this.path, this.value);
/*  46:    */   }
/*  47:    */   
/*  48:    */   public String getValue()
/*  49:    */     throws SCMException
/*  50:    */   {
/*  51: 45 */     if ("_SCM_SYNC_FAIL_".equals(this.value)) {
/*  52: 46 */       throw new SCMException("Sync fail.");
/*  53:    */     }
/*  54: 48 */     return this.value;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public void sync()
/*  58:    */     throws SCMException
/*  59:    */   {
/*  60:    */     try
/*  61:    */     {
/*  62: 54 */       this.zkNode.sync(false);
/*  63: 55 */       this.value = ((String)this.zkNode.getData());
/*  64: 56 */       saveToLocalFileCache(this.path, this.value);
/*  65:    */     }
/*  66:    */     catch (DataException ex)
/*  67:    */     {
/*  68: 58 */       logger.warn("Can not get config content of " + this.path + ",will try to load from local file.", ex);
/*  69:    */       try
/*  70:    */       {
/*  71: 60 */         this.value = loadFromLocalFileCache(this.path);
/*  72:    */       }
/*  73:    */       catch (Exception e)
/*  74:    */       {
/*  75: 62 */         logger.error("Exception when Load " + this.path + " from local file,Sync fail.", e);
/*  76: 63 */         this.value = "_SCM_SYNC_FAIL_";
/*  77: 64 */         throw new SCMException("Sync " + this.path + " fail.", e);
/*  78:    */       }
/*  79:    */     }
/*  80:    */     finally
/*  81:    */     {
/*  82: 67 */       this.zkNode.monitor(this.value, this);
/*  83:    */     }
/*  84:    */   }
/*  85:    */   
/*  86:    */   @Deprecated
/*  87:    */   public void monitor(SCMListener scmListener)
/*  88:    */   {
/*  89: 74 */     monitor(this.value, scmListener);
/*  90:    */   }
/*  91:    */   
/*  92:    */   public void monitor(String expect, final SCMListener scmListener)
/*  93:    */   {
/*  94: 79 */     this.zkNode.monitor(expect, new DataListener()
/*  95:    */     {
/*  96:    */       public void dataChanged(String oldData, String newData)
/*  97:    */       {
/*  98: 82 */         scmListener.execute(oldData, newData);
/*  99:    */       }
/* 100:    */     });
/* 101:    */   }
/* 102:    */   
/* 103:    */   public void destroy()
/* 104:    */   {
/* 105: 89 */     this.zkNode.destroy();
/* 106:    */   }
/* 107:    */   
/* 108:    */   private String loadFromLocalFileCache(String path)
/* 109:    */     throws Exception
/* 110:    */   {
/* 111: 94 */     File file = new File(getLocalFilePath(this.configuration.getAppCode(), this.configuration.getScmServer(), path));
/* 112: 95 */     if (!file.exists()) {
/* 113: 96 */       throw new IOException("LocalFile " + file.getPath() + " not exist.");
/* 114:    */     }
/* 115: 97 */     FileInputStream in = null;
/* 116: 98 */     int size = 512;
/* 117: 99 */     StringBuilder sb = new StringBuilder(512);
/* 118:    */     try
/* 119:    */     {
/* 120:101 */       in = new FileInputStream(file);
/* 121:102 */       int length = 8192;
/* 122:103 */       byte[] data = new byte[8192];
/* 123:    */       int n;
/* 124:105 */       while ((n = in.read(data)) != -1) {
/* 125:106 */         sb.append(new String(data, 0, n, "UTF-8"));
/* 126:    */       }
/* 127:108 */       return sb.toString();
/* 128:    */     }
/* 129:    */     finally
/* 130:    */     {
/* 131:110 */       if (in != null) {
/* 132:    */         try
/* 133:    */         {
/* 134:112 */           in.close();
/* 135:    */         }
/* 136:    */         catch (IOException e)
/* 137:    */         {
/* 138:114 */           logger.error(e.getMessage());
/* 139:    */         }
/* 140:    */       }
/* 141:    */     }
/* 142:    */   }
/* 143:    */   
/* 144:    */   private synchronized void saveToLocalFileCache(String path, String value)
/* 145:    */   {
/* 146:123 */     FileOutputStream out = null;
/* 147:124 */     PrintWriter writer = null;
/* 148:    */     try
/* 149:    */     {
/* 150:126 */       File file = new File(getLocalFilePath(this.configuration.getAppCode(), this.configuration.getScmServer(), path));
/* 151:127 */       if (!file.exists()) {
/* 152:    */         try
/* 153:    */         {
/* 154:129 */           file.createNewFile();
/* 155:    */         }
/* 156:    */         catch (RuntimeException e)
/* 157:    */         {
/* 158:131 */           logger.error(e.getMessage(), e);
/* 159:    */         }
/* 160:    */       }
/* 161:134 */       out = new FileOutputStream(file);
/* 162:135 */       BufferedOutputStream stream = new BufferedOutputStream(out);
/* 163:136 */       writer = new PrintWriter(new BufferedWriter(new OutputStreamWriter(stream, "UTF-8")));
/* 164:137 */       writer.write(value == null ? "" : value);
/* 165:138 */       writer.flush(); return;
/* 166:    */     }
/* 167:    */     catch (IOException e)
/* 168:    */     {
/* 169:140 */       logger.error("save localFile config error, path= " + this.configuration.getAppCode() + "-" + this.configuration.getScmServer() + "-" + path, e);
/* 170:    */     }
/* 171:    */     finally
/* 172:    */     {
/* 173:143 */       if (writer != null) {
/* 174:144 */         writer.close();
/* 175:    */       }
/* 176:146 */       if (out != null) {
/* 177:    */         try
/* 178:    */         {
/* 179:148 */           out.close();
/* 180:    */         }
/* 181:    */         catch (IOException e)
/* 182:    */         {
/* 183:150 */           logger.error(e.getMessage());
/* 184:    */         }
/* 185:    */       }
/* 186:    */     }
/* 187:    */   }
/* 188:    */   
/* 189:    */   private String getLocalFilePath(String appCode, String scmServer, String path)
/* 190:    */   {
/* 191:160 */     if (path.contains(PATH_SEPARATOR)) {
/* 192:161 */       path = StringUtils.substringAfterLast(path, PATH_SEPARATOR);
/* 193:    */     }
/* 194:163 */     String res = SCMConstant.FILE_PATH + PATH_SEPARATOR + StringFilter(MD5Utils.getMD5(new StringBuilder().append(appCode).append("-").append(scmServer).append("-").append(ServerNameGetter.getServerName()).append("-").append(path).toString()));
/* 195:    */     
/* 196:    */ 
/* 197:166 */     logger.info("LocalFilePath ==========" + res);
/* 198:167 */     return res;
/* 199:    */   }
/* 200:    */   
/* 201:    */   public static String StringFilter(String str)
/* 202:    */     throws PatternSyntaxException
/* 203:    */   {
/* 204:172 */     Pattern p = Pattern.compile("[`~!@#$%^&*()+=|{}':;',//[//].<>/?~！@#￥%……&*（）——+|{}【】‘；：”“’。，、？]");
/* 205:173 */     Matcher m = p.matcher(str);
/* 206:174 */     return m.replaceAll("").trim();
/* 207:    */   }
/* 208:    */ }


/* Location:           F:\thirty\SUNING\统一配置管理（SCM）\snf-scm-client-2.2.0.jar
 * Qualified Name:     com.suning.framework.scm.client.SCMNodeImpl
 * JD-Core Version:    0.7.0.1
 */