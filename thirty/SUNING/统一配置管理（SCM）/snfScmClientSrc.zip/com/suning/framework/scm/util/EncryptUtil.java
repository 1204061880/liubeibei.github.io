/*  1:   */ package com.suning.framework.scm.util;
/*  2:   */ 
/*  3:   */ import java.net.URLDecoder;
/*  4:   */ import java.net.URLEncoder;
/*  5:   */ import javax.crypto.Mac;
/*  6:   */ import javax.crypto.SecretKey;
/*  7:   */ import javax.crypto.spec.SecretKeySpec;
/*  8:   */ 
/*  9:   */ public class EncryptUtil
/* 10:   */ {
/* 11:   */   public static final String ENCODER_UTF8 = "UTF-8";
/* 12:   */   public static final String ENCODER_ISO8859 = "ISO-8859-1";
/* 13:   */   public static final String KEY_MAC = "HmacMD5";
/* 14:   */   
/* 15:   */   public static String encryptHMAC(String data, String key)
/* 16:   */     throws Exception
/* 17:   */   {
/* 18:56 */     String keyStr = URLDecoder.decode(key, "UTF-8");
/* 19:57 */     byte[] keyRaw = keyStr.getBytes("ISO-8859-1");
/* 20:58 */     SecretKey secretKey = new SecretKeySpec(keyRaw, "HmacMD5");
/* 21:59 */     Mac mac = Mac.getInstance(secretKey.getAlgorithm());
/* 22:60 */     mac.init(secretKey);
/* 23:61 */     byte[] raw = mac.doFinal(data.getBytes("UTF-8"));
/* 24:62 */     return URLEncoder.encode(new String(raw, "ISO-8859-1"), "UTF-8");
/* 25:   */   }
/* 26:   */ }


/* Location:           F:\thirty\SUNING\统一配置管理（SCM）\snf-scm-client-2.2.0.jar
 * Qualified Name:     com.suning.framework.scm.util.EncryptUtil
 * JD-Core Version:    0.7.0.1
 */