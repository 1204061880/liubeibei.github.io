package com.suning.framework.scm.client;

public abstract interface SCMListener
{
  public abstract void execute(String paramString1, String paramString2);
}


/* Location:           F:\thirty\SUNING\统一配置管理（SCM）\snf-scm-client-2.2.0.jar
 * Qualified Name:     com.suning.framework.scm.client.SCMListener
 * JD-Core Version:    0.7.0.1
 */