/*   1:    */ 
/*   2:    */ 
/*   3:    */ com.suning.framework.scm.util.CompressUtils
/*   4:    */ com.suning.framework.scm.util.EncryptUtil
/*   5:    */ com.suning.framework.scm.util.HttpClient
/*   6:    */ com.suning.framework.scm.util.ParamUtil
/*   7:    */ com.suning.framework.scm.util.StringUtils
/*   8:    */ com.suning.framework.statistics.VersionStatistics
/*   9:    */ com.suning.framework.zookeeper.Deserializer
/*  10:    */ com.suning.framework.zookeeper.ZkClient
/*  11:    */ com.suning.framework.zookeeper.ZkClient.ReadResult
/*  12:    */ com.suning.framework.zookeeper.ZkConnection
/*  13:    */ com.suning.framework.zookeeper.ZkNode
/*  14:    */ java.util.HashMap
/*  15:    */ java.util.Map
/*  16:    */ java.util.concurrent.ConcurrentHashMap
/*  17:    */ org.slf4j.Logger
/*  18:    */ org.slf4j.LoggerFactory
/*  19:    */ 
/*  20:    */ SCMClientImpl
/*  21:    */   
/*  22:    */ 
/*  23: 24 */   logger = getLogger
/*  24: 25 */   DESERIALIZER = ()
/*  25: 26 */   , scmNodes = ()
/*  26:    */   PATH_SEPARATOR = "/"
/*  27:    */   GLOBAL_PATH = "/global"
/*  28:    */   ROOT = "/scmv1"
/*  29:    */   DB_ROOT = "/scm"
/*  30:    */   zkClient
/*  31:    */   config
/*  32:    */   
/*  33:    */   
/*  34:    */   getInstance
/*  35:    */     
/*  36:    */   
/*  37: 37 */     getSCMClient()
/*  38:    */   
/*  39:    */   
/*  40:    */   
/*  41:    */   setConfigFilePath
/*  42:    */   
/*  43: 42 */     setConfigFilePath
/*  44:    */   
/*  45:    */   
/*  46:    */   
/*  47:    */   getInstance
/*  48:    */     
/*  49:    */   
/*  50: 47 */     getSCMClient
/*  51:    */   
/*  52:    */   
/*  53:    */   SCMClientImpl
/*  54:    */     
/*  55:    */   
/*  56: 52 */     reportVersiongetAppCode(), getScmServer(), 
/*  57: 53 */     config = 
/*  58:    */     
/*  59: 55 */     zkClient = new ZkClient(config.getZkServer().trim(), ZkConnection.digestCredentials(config.getAppCode().trim(), config.getSecretKey().trim()));
/*  60:    */   }
/*  61:    */   
/*  62:    */   public SCMNode getConfig(String path)
/*  63:    */   {
/*  64: 62 */     String formatedPath = parse(path);
/*  65: 63 */     SCMNode scmNode = (SCMNode)this.scmNodes.get(formatedPath);
/*  66: 64 */     if (scmNode != null) {
/*  67: 65 */       return scmNode;
/*  68:    */     }
/*  69: 67 */     synchronized (this.scmNodes)
/*  70:    */     {
/*  71: 68 */       scmNode = (SCMNode)this.scmNodes.get(formatedPath);
/*  72: 69 */       if (scmNode != null) {
/*  73: 70 */         return scmNode;
/*  74:    */       }
/*  75: 72 */       ZkNode<String> zkNode = new ZkNode(this.zkClient, getFullPath(this.config.getAppCode(), formatedPath), DESERIALIZER, true, false, true);
/*  76:    */       
/*  77:    */ 
/*  78:    */ 
/*  79:    */ 
/*  80: 77 */       scmNode = new SCMNodeImpl(this.config, formatedPath, zkNode);
/*  81: 78 */       this.scmNodes.put(formatedPath, scmNode);
/*  82: 79 */       return scmNode;
/*  83:    */     }
/*  84:    */   }
/*  85:    */   
/*  86:    */   private static String getPropertyValue(String key)
/*  87:    */   {
/*  88: 84 */     String value = System.getenv(key);
/*  89: 85 */     if (StringUtils.isEmpty(value)) {
/*  90: 86 */       value = System.getProperty(key);
/*  91:    */     }
/*  92: 88 */     return value;
/*  93:    */   }
/*  94:    */   
/*  95:    */   public static String parse(String path)
/*  96:    */   {
/*  97: 92 */     if ((path == null) || (path.length() == 0)) {
/*  98: 92 */       return path;
/*  99:    */     }
/* 100: 93 */     int start = -1;
/* 101: 94 */     int end = -1;
/* 102: 95 */     StringBuilder sb = new StringBuilder();
/* 103: 96 */     for (int i = 0; i < path.length(); i++)
/* 104:    */     {
/* 105: 97 */       if ((path.charAt(i) == '$') && (start == -1) && (i < path.length() - 1) && (path.charAt(i + 1) == '{'))
/* 106:    */       {
/* 107: 98 */         start = i;
/* 108: 99 */         i++;
/* 109:    */       }
/* 110:100 */       else if ((path.charAt(i) == '}') && (start != -1))
/* 111:    */       {
/* 112:101 */         end = i;
/* 113:    */       }
/* 114:103 */       if (start == -1) {
/* 115:103 */         sb.append(path.charAt(i));
/* 116:    */       }
/* 117:104 */       if ((start != -1) && (end != -1))
/* 118:    */       {
/* 119:105 */         String value = getPropertyValue(path.substring(start + 2, end));
/* 120:106 */         if (StringUtils.isEmpty(value)) {
/* 121:107 */           throw new IllegalArgumentException(String.format("No system property %s of %s", new Object[] { path.substring(start + 2, end), path }));
/* 122:    */         }
/* 123:109 */         sb.append(value);
/* 124:110 */         start = -1;
/* 125:111 */         end = -1;
/* 126:    */       }
/* 127:    */     }
/* 128:114 */     if ((start != -1) && (end == -1)) {
/* 129:114 */       sb.append(path.substring(start));
/* 130:    */     }
/* 131:115 */     return sb.toString();
/* 132:    */   }
/* 133:    */   
/* 134:    */   public static String getFullPath(String appCode, String path)
/* 135:    */   {
/* 136:120 */     if (path.indexOf("/") == 0) {
/* 137:121 */       path = StringUtils.substringAfter(path, "/");
/* 138:    */     }
/* 139:    */     String fullPath;
/* 140:    */     String fullPath;
/* 141:123 */     if (path.contains("/global".substring(1))) {
/* 142:124 */       fullPath = "/scmv1/" + path;
/* 143:    */     } else {
/* 144:126 */       fullPath = "/scmv1/" + appCode + "/" + path;
/* 145:    */     }
/* 146:128 */     return fullPath;
/* 147:    */   }
/* 148:    */   
/* 149:    */   public static String getFullOperationPath(String appCode, String path)
/* 150:    */   {
/* 151:134 */     if (path.indexOf("/") == 0) {
/* 152:135 */       path = StringUtils.substringAfter(path, "/");
/* 153:    */     }
/* 154:    */     String fullPath;
/* 155:    */     String fullPath;
/* 156:137 */     if (path.contains("/global".substring(1))) {
/* 157:138 */       fullPath = "/scm/" + path;
/* 158:    */     } else {
/* 159:140 */       fullPath = "/scm/" + appCode + "/" + path;
/* 160:    */     }
/* 161:142 */     return fullPath;
/* 162:    */   }
/* 163:    */   
/* 164:    */   public void destroy()
/* 165:    */   {
/* 166:147 */     synchronized (this.scmNodes)
/* 167:    */     {
/* 168:148 */       for (SCMNode scmNode : this.scmNodes.values()) {
/* 169:    */         try
/* 170:    */         {
/* 171:150 */           scmNode.destroy();
/* 172:    */         }
/* 173:    */         catch (Throwable ex) {}
/* 174:    */       }
/* 175:155 */       this.zkClient.close();
/* 176:    */     }
/* 177:    */   }
/* 178:    */   
/* 179:    */   public void createConfig(String user, String path, String value)
/* 180:    */     throws SCMException
/* 181:    */   {
/* 182:162 */     remoteOperationConfig(user, getFullOperationPath(this.config.getAppCode(), path), value, "create");
/* 183:    */   }
/* 184:    */   
/* 185:    */   public void updateConfig(String user, String path, String value)
/* 186:    */     throws SCMException
/* 187:    */   {
/* 188:168 */     remoteOperationConfig(user, getFullOperationPath(this.config.getAppCode(), path), value, "update");
/* 189:    */   }
/* 190:    */   
/* 191:    */   public void deleteConfig(String user, String path)
/* 192:    */     throws SCMException
/* 193:    */   {
/* 194:174 */     remoteOperationConfig(user, getFullOperationPath(this.config.getAppCode(), path), "", "delete");
/* 195:    */   }
/* 196:    */   
/* 197:    */   public void remoteOperationConfig(String user, String path, String config, String operationType)
/* 198:    */     throws SCMException
/* 199:    */   {
/* 200:180 */     Map<String, Object> map = new HashMap();
/* 201:    */     
/* 202:182 */     map.put("appCode", this.config.getAppCode());
/* 203:183 */     map.put("path", path);
/* 204:184 */     map.put("config", config);
/* 205:185 */     map.put("operationType", operationType);
/* 206:186 */     map.put("user", user);
/* 207:187 */     String result = sendDataByPost(this.config.getScmServer() + "/operationConfig.htm", map);
/* 208:    */     
/* 209:189 */     String[] resultsStrings = result.split(",");
/* 210:191 */     if ("failure".equals(resultsStrings[0])) {
/* 211:192 */       throw new SCMException(resultsStrings[1]);
/* 212:    */     }
/* 213:    */   }
/* 214:    */   
/* 215:    */   protected String sendDataByPost(String url, Map<String, Object> dataMap)
/* 216:    */   {
/* 217:208 */     if ((url == null) || (url.length() == 0)) {
/* 218:209 */       throw new IllegalArgumentException("url is empty!");
/* 219:    */     }
/* 220:213 */     dataMap.put("timeStamp", Long.valueOf(System.currentTimeMillis()));
/* 221:    */     try
/* 222:    */     {
/* 223:216 */       String digestStr = ParamUtil.getParamFromMap(dataMap);
/* 224:    */       
/* 225:218 */       String mac = EncryptUtil.encryptHMAC(digestStr, this.config.getSecretKey());
/* 226:    */       
/* 227:220 */       String paramStr = ParamUtil.getEncodedParamFromMap(dataMap);
/* 228:    */       
/* 229:222 */       String result = HttpClient.sendByPost(url, paramStr + "&mac=" + mac, 30000, 3, 2000);
/* 230:    */       
/* 231:224 */       logger.info("Result from SCM server:" + result);
/* 232:    */       
/* 233:226 */       return result;
/* 234:    */     }
/* 235:    */     catch (Exception e)
/* 236:    */     {
/* 237:229 */       throw new SCMException("Exception occur when send data to scm server.", e);
/* 238:    */     }
/* 239:    */   }
/* 240:    */   
/* 241:    */   public ZkClient getInternalZkClient()
/* 242:    */   {
/* 243:234 */     return this.zkClient;
/* 244:    */   }
/* 245:    */   
/* 246:    */   public String getAppCode()
/* 247:    */   {
/* 248:239 */     return this.config.getAppCode();
/* 249:    */   }
/* 250:    */   
/* 251:    */   public String getSecureKey(String appCode)
/* 252:    */   {
/* 253:    */     try
/* 254:    */     {
/* 255:245 */       ZkClient.ReadResult readResult = this.zkClient.readData("/scmv1/" + appCode, 30000L);
/* 256:    */       
/* 257:247 */       return new String(readResult.data);
/* 258:    */     }
/* 259:    */     catch (Exception e)
/* 260:    */     {
/* 261:249 */       throw new SCMException(e.getMessage(), e);
/* 262:    */     }
/* 263:    */   }
/* 264:    */   
/* 265:    */   public String getSecretKey()
/* 266:    */   {
/* 267:254 */     return this.config.getSecretKey();
/* 268:    */   }
/* 269:    */   
/* 270:    */   public String getZkServer()
/* 271:    */   {
/* 272:258 */     return this.config.getZkServer();
/* 273:    */   }
/* 274:    */   
/* 275:    */   public SCMNode getGlobalConfig(String path)
/* 276:    */     throws SCMException
/* 277:    */   {
/* 278:263 */     if (path.indexOf("/") == 0) {
/* 279:264 */       path = StringUtils.substringAfter(path, "/");
/* 280:    */     }
/* 281:266 */     return getConfig("/global/" + path);
/* 282:    */   }
/* 283:    */   
/* 284:    */   public SCMClient.Environment getEnvironment()
/* 285:    */   {
/* 286:271 */     return this.config.getEnvironment();
/* 287:    */   }
/* 288:    */   
/* 289:    */   public SCMNode readConfig(String appCode, String path)
/* 290:    */   {
/* 291:276 */     if ((!StringUtils.isEmpty(appCode)) && (!StringUtils.isEmpty(path)))
/* 292:    */     {
/* 293:277 */       String formatedPath = parse(path);
/* 294:278 */       if (formatedPath.indexOf("/") == 0) {
/* 295:279 */         formatedPath = StringUtils.substringAfter(formatedPath, "/");
/* 296:    */       }
/* 297:281 */       if (appCode.indexOf("/") == 0) {
/* 298:282 */         appCode = StringUtils.substringAfter(appCode, "/");
/* 299:    */       }
/* 300:284 */       String zkPath = "/scmv1/" + appCode + "/" + formatedPath;
/* 301:285 */       SCMNode scmNode = (SCMNode)this.scmNodes.get(zkPath);
/* 302:286 */       if (scmNode != null) {
/* 303:287 */         return scmNode;
/* 304:    */       }
/* 305:289 */       synchronized (this.scmNodes)
/* 306:    */       {
/* 307:290 */         scmNode = (SCMNode)this.scmNodes.get(zkPath);
/* 308:291 */         if (scmNode != null) {
/* 309:292 */           return scmNode;
/* 310:    */         }
/* 311:294 */         ZkNode<String> zkNode = new ZkNode(this.zkClient, zkPath, DESERIALIZER, true, false, true);
/* 312:    */         
/* 313:    */ 
/* 314:    */ 
/* 315:    */ 
/* 316:299 */         scmNode = new SCMNodeImpl(this.config, zkPath, zkNode);
/* 317:300 */         this.scmNodes.put(zkPath, scmNode);
/* 318:301 */         return scmNode;
/* 319:    */       }
/* 320:    */     }
/* 321:304 */     return null;
/* 322:    */   }
/* 323:    */   
/* 324:    */   public static class CompressStrDeserializer
/* 325:    */     implements Deserializer<String>
/* 326:    */   {
/* 327:    */     public String deserialize(byte[] data)
/* 328:    */     {
/* 329:311 */       return CompressUtils.deserialize(data);
/* 330:    */     }
/* 331:    */   }
/* 332:    */ }


/* Location:           F:\thirty\SUNING\统一配置管理（SCM）\snf-scm-client-2.2.0.jar
 * Qualified Name:     com.suning.framework.scm.client.SCMClientImpl
 * JD-Core Version:    0.7.0.1
 */